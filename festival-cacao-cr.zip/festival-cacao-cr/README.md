# Festival de Cacao y Chocolate de Especialidad de Costa Rica — sitio web

Sitio estático (HTML + CSS + JS, sin frameworks) para la primera edición del festival.
**6 y 7 de noviembre · Campus Benjamín Núñez, UNA, Lagunilla de Heredia.**

## Estructura

```
├── index.html          Página principal (perfil, objetivos, programa, registro)
├── organizadores.html  Área interna: documentos de Drive y comisiones (noindex)
├── css/styles.css      Estilos (paleta de la identidad gráfica del festival)
├── js/main.js          Menú móvil, animaciones y envío del formulario
└── assets/logo.png     Identidad gráfica
```

## Publicar en GitHub Pages (5 minutos)

1. Cree un repositorio en GitHub, por ejemplo `festival-cacao-cr`.
2. Suba todos los archivos de esta carpeta (arrastrándolos en la web de GitHub o con git):
   ```bash
   git init
   git add .
   git commit -m "Sitio del festival, primera edición"
   git branch -M main
   git remote add origin https://github.com/SU_USUARIO/festival-cacao-cr.git
   git push -u origin main
   ```
3. En el repositorio: **Settings → Pages → Source: Deploy from a branch → main / (root) → Save**.
4. En un par de minutos el sitio estará en
   `https://SU_USUARIO.github.io/festival-cacao-cr/`.

Para usar un dominio propio (ej. `festivalcacaocr.org`), agréguelo en Settings → Pages → Custom domain.

## Conectar el formulario de registro

GitHub Pages no procesa formularios; hay dos opciones sencillas:

**Opción A — Formspree (recomendada, gratis hasta 50 envíos/mes):**
1. Cree una cuenta en [formspree.io](https://formspree.io) y un formulario nuevo.
2. Copie el código del endpoint (algo como `https://formspree.io/f/abcd1234`).
3. En `index.html`, reemplace `SU_CODIGO` en la línea:
   ```html
   <form class="reg-form" action="https://formspree.io/f/SU_CODIGO" method="POST">
   ```
Los registros llegarán a su correo y podrá exportarlos a hoja de cálculo.

**Opción B — Google Forms:**
Cree el formulario en Google Forms y reemplace el `<form>…</form>` de `index.html`
por el código de inserción (Enviar → `< >` → Insertar HTML), o simplemente enlace
el botón "Registrarse" al formulario.

## Área de organizadores

- `organizadores.html` no aparece en el menú público y tiene `noindex`, pero **no es
  privada**: cualquier persona con el enlace puede abrirla. La seguridad real está en
  los permisos de Google Drive — comparta cada documento solo con los correos del comité.
- Para agregar documentos, edite la lista `doc-list` en `organizadores.html`
  (los enlaces marcados `#` son marcadores de posición).

## Personalización rápida

- **Colores y tipografía:** variables al inicio de `css/styles.css`.
- **Correo de contacto:** en el pie de página de `index.html` (`info@festivalcacaocr.org` es provisional).
- **Programa:** sección `#programa` de `index.html`, organizada por piso.
